#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
//#include <sys/wait.h>
#include <sys/types.h>
#include <ctype.h>
#include <errno.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>

#define BLOCK_SIZE 1024
#define MAX_FILE_SIZE 4194304 // 4GB of file size
#define FREE_ARRAY_SIZE 248 // free and inode array size
#define INODE_SIZE 64

/*************** super block structure**********************/
typedef struct {
        unsigned int isize; // 4 byte
        unsigned int fsize;
        unsigned int nfree;
        unsigned short free[FREE_ARRAY_SIZE];
        unsigned int ninode;
        unsigned short inode[FREE_ARRAY_SIZE];
        unsigned short flock;
        unsigned short ilock;
        unsigned short fmod;
        unsigned int time[2];
} super_block;

/****************inode structure ************************/
typedef struct {
        unsigned short flags; // 2 bytes
        char nlinks;  // 1 byte
        char uid;
        char gid;
        unsigned int size; // 32bits  2^32 = 4GB filesize
        unsigned short addr[22]; // to make total size = 64 byte inode size
        unsigned int actime;
        unsigned int modtime;
} Inode;


typedef struct
{
        unsigned short inode;
        char filename[14];
}dEntry;


super_block super;
int fd;
char pwd[100];
int curINodeNumber;
char fileSystemPath[100];
int total_inodes_count;

Inode getInode(int INumber){
        Inode iNode;
        int blockNumber = (INumber * INODE_SIZE) / BLOCK_SIZE;    // need to remove 
        int offset = (INumber * INODE_SIZE) % BLOCK_SIZE;
        lseek(fd,(BLOCK_SIZE * blockNumber) + offset, SEEK_SET);
        read(fd,&iNode,INODE_SIZE);
        return iNode;
}


int openfs(const char *filename)
{
	fd=open(filename,2);
	lseek(fd,BLOCK_SIZE,SEEK_SET);
	read(fd,&super,sizeof(super));
	lseek(fd,2*BLOCK_SIZE,SEEK_SET);
        Inode root = getInode(1);
	read(fd,&root,sizeof(root));
	return 1;
}
void initfs(char* path, int total_blocks, int total_inodes)
{
        printf("\n filesystem intialization started \n");
        total_inodes_count = total_inodes;
        char emptyBlock[BLOCK_SIZE] = {0};
        int no_of_bytes,i,blockNumber,iNumber;

        //init isize (Number of blocks for inode
        if(((total_inodes*INODE_SIZE)%BLOCK_SIZE) == 0) // 300*64 % 1024
                super.isize = (total_inodes*INODE_SIZE)/BLOCK_SIZE;
        else
                super.isize = (total_inodes*INODE_SIZE)/BLOCK_SIZE+1;

        //init fsize
        super.fsize = total_blocks;

        //create file for File System
        if((fd = open(path,O_RDWR|O_CREAT,0600))== -1)
        {
                printf("\n file opening error [%s]\n",strerror(errno));
                return;
        }
        strcpy(fileSystemPath,path);

        writeToBlock(total_blocks-1,emptyBlock,BLOCK_SIZE); // writing empty block to last block

        // add all blocks to the free array
        super.nfree = 0;
        for (blockNumber= 1+super.isize; blockNumber< total_blocks; blockNumber++)
                addFreeBlock(blockNumber);

        // add free Inodes to inode array
        super.ninode = 0;
        for (iNumber=1; iNumber < total_inodes ; iNumber++)
                addFreeInode(iNumber);


        super.flock = 'f';
        super.ilock = 'i';
        super.fmod = 'f';
        super.time[0] = 0;
        super.time[1] = 0;

        //write Super Block
        writeToBlock (0,&super,BLOCK_SIZE);

        //allocate empty space for i-nodes
        for (i=1; i <= super.isize; i++)
                writeToBlock(i,emptyBlock,BLOCK_SIZE);

        createRootDirectory();
}

void quit()
{
        close(fd);
        exit(0);
}



int main(int argc, char *argv[])
{
        char c;

        printf("\n Clearing screen \n");
        system("clear");

        unsigned int blk_no =0, inode_no=0;
        char *fs_path;
        char *arg1, *arg2;
        char *my_argv, cmd[512];

        while(1)
        {
                printf("\n%s@%s>>>",fileSystemPath,pwd);
                scanf(" %[^\n]s", cmd);
                my_argv = strtok(cmd," ");

                if(strcmp(my_argv, "initfs")==0)
                {

                        fs_path = strtok(NULL, " ");
                        arg1 = strtok(NULL, " ");
                        arg2 = strtok(NULL, " ");
                        if(access(fs_path, X_OK) != -1)
                        {
                                printf("filesystem already exists. \n");
                                printf("same file system will be used\n");
                        }
                        else
                        {
                                if (!arg1 || !arg2)
                                        printf(" insufficient arguments to proceed\n");
                                else
                                {
                                        blk_no = atoi(arg1);
                                        inode_no = atoi(arg2);
                                        initfs(fs_path,blk_no, inode_no);
                                }
                        }
                        my_argv = NULL;
                }
                else if(strcmp(my_argv, "q")==0){
                        quit();
                }
                else if(strcmp(my_argv, "ls")==0){
                        ls();
                }
                else if(strcmp(my_argv, "mkdir")==0){
                        arg1 = strtok(NULL, " ");
                        makedir(arg1);
                }
                else if(strcmp(my_argv, "cd")==0){
                        arg1 = strtok(NULL, " ");
                        changedir(arg1);
                }
                else if(strcmp(my_argv, "cpin")==0){
                        arg1 = strtok(NULL, " ");
                        arg2 = strtok(NULL, " ");
                        copyIn(arg1,arg2);
                }
                else if(strcmp(my_argv, "cpout")==0){
                        arg1 = strtok(NULL, " ");
                        arg2 = strtok(NULL, " ");
                        copyOut(arg1,arg2);
                }
                else if(strcmp(my_argv, "rm")==0){
                        arg1 = strtok(NULL, " ");
                        rm(arg1);
                }
                else if(strcmp(my_argv, "remDir")==0){
                        arg1 = strtok(NULL, " ");
                        removeDir(arg1);
                }else if(strcmp(my_argv, "openfs")==0){
                        arg1 = strtok(NULL, " ");
                        openfs(arg1);
                }
                else if(strcmp(my_argv, "pwd")==0){
                        printf("%s\n",pwd);
                }
               

        }
}
